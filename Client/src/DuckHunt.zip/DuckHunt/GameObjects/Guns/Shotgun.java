package DuckHunt.GameObjects.Guns;


import DuckHunt.GameObjects.Bullets.Basic;

public class Shotgun extends Gun {

    public Shotgun() {
        super(700, 100, 7 , "Images/Songs/2.wav", new Basic(),2);
    }

}
