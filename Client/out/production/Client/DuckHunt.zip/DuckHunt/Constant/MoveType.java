package DuckHunt.Constant;

public enum MoveType {
	
	Damage(),
	Left(),
	death(),
	;
	
	int Responses(int S){
		return S;
	}
	
}
