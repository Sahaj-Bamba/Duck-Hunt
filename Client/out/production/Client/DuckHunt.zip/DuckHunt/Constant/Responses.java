package DuckHunt.Constant;

public enum Responses {
	
	ERROR(),
	OK(),
	
	;
	
	int Responses(int S){
		return S;
	}
	
}
