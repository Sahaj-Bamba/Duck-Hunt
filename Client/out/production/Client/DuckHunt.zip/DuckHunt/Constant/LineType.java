package DuckHunt.Constant;

public enum LineType {
	
	Horizontal(),
	Vertical(),
	;
	
	int Responses(int S){
		return S;
	}
	
}
