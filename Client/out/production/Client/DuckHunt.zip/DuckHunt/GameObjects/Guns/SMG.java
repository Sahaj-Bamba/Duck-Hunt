package DuckHunt.GameObjects.Guns;


import DuckHunt.GameObjects.Bullets.Basic;

public class SMG extends Gun {

    public SMG() {
        super(10, 1, 5, "Images/Songs/3.wav",new Basic(),3);
    }

}
