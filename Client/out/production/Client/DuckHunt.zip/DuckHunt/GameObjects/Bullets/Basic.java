package DuckHunt.GameObjects.Bullets;

public class Basic extends Bullet {
    public Basic() {
        super(1);
    }
}
